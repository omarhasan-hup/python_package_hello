def main():
    print('This is the print to say HI \n')

def hello2():
    print('This is another HI deiifernt than the main \n')