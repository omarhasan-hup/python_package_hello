def new_hi():
    print('hiiiiii from the another module')